/*
 * Coffee Bliss – JavaScript
 *
 * This script ensures smooth scrolling when users click the “Discover Our Brews”
 * button. It gently scrolls to the menu section without abrupt jumps.
 */

document.addEventListener('DOMContentLoaded', () => {
  const button = document.querySelector('.button');
  const menuSection = document.querySelector('#menu');

  button?.addEventListener('click', event => {
    event.preventDefault();
    // Use the built‑in Element.scrollIntoView method for smooth scroll
    menuSection?.scrollIntoView({ behavior: 'smooth' });
  });
});